const jwt = require("jsonwebtoken");
const db = require("../config/db");

const JWT_SECRET = process.env.JWT_SECRET || "toon_cinema_secret_key";

// Xác thực token và lấy thông tin user mới nhất (kèm role) từ DB
async function verifyToken(req, res, next) {
  try {
    const authHeader = req.headers.authorization || "";
    const token = authHeader.startsWith("Bearer ")
      ? authHeader.slice(7).trim()
      : null;

    if (!token) {
      return res.status(401).json({ message: "Vui lòng đăng nhập để tiếp tục" });
    }

    const decoded = jwt.verify(token, JWT_SECRET);

    // Truy vấn lại DB để đảm bảo role luôn cập nhật mới nhất
    const [rows] = await db.query(
      "SELECT id, full_name, email, role FROM users WHERE id = ? LIMIT 1",
      [decoded.id]
    );

    if (!rows || rows.length === 0) {
      return res.status(401).json({ message: "Tài khoản không tồn tại" });
    }

    req.user = rows[0];
    next();
  } catch (err) {
    return res.status(401).json({ message: "Phiên đăng nhập không hợp lệ hoặc đã hết hạn" });
  }
}

// Chỉ cho phép tài khoản có role === 'admin'
function requireAdmin(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ message: "Vui lòng đăng nhập" });
  }

  if (String(req.user.role).toLowerCase() !== "admin") {
    return res.status(403).json({
      message: "Truy cập bị từ chối: Chỉ tài khoản Admin mới có quyền truy cập",
    });
  }

  next();
}

module.exports = {
  verifyToken,
  requireAdmin,
};