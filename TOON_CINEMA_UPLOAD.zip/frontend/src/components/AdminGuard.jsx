// src/components/AdminGuard.jsx
import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";

export default function AdminGuard({ children, onBackHome }) {
  const { user, isAdmin, login, logout, showToast } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [loading, setLoading] = useState(false);

  // Đã đăng nhập và đúng role === 'admin' -> cho vào trang quản trị
  if (user && isAdmin) {
    return <>{children}</>;
  }

  const handleAdminLogin = async (e) => {
    e.preventDefault();
    setErrorMsg("");
    setLoading(true);
    try {
      const loggedUser = await login(email.trim(), password);
      if (String(loggedUser.role).toLowerCase() !== "admin") {
        setErrorMsg("Tài khoản này không có quyền Admin.");
        showToast("Tài khoản này không có quyền Admin!", "error");
      }
    } catch (err) {
      setErrorMsg(err.message || "Đăng nhập thất bại");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: 420, margin: "48px auto", padding: 24, border: "1px solid #e5e7eb", borderRadius: 12 }}>
      <h2 style={{ marginTop: 0 }}>Xác thực quyền Admin</h2>

      {user && !isAdmin ? (
        <div>
          <p style={{ color: "#b91c1c" }}>
            Tài khoản <strong>{user.email}</strong> hiện có quyền <strong>{user.role}</strong>, không thể truy cập Trang Quản Trị.
          </p>
          <div style={{ display: "flex", gap: 10 }}>
            <button type="button" onClick={logout}>
              Đăng xuất tài khoản này
            </button>
            <button type="button" onClick={onBackHome}>
              Về trang chủ
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleAdminLogin} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <p style={{ margin: 0, color: "#4b5563", fontSize: 14 }}>
            Vui lòng nhập email và mật khẩu của tài khoản Admin để tiếp tục.
          </p>

          {errorMsg && (
            <div style={{ background: "#fef2f2", color: "#b91c1c", padding: 10, borderRadius: 8, fontSize: 14 }}>
              {errorMsg}
            </div>
          )}

          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email admin (vd: admin@gmail.com)"
            style={{ padding: 10, borderRadius: 8, border: "1px solid #d1d5db" }}
          />
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Mật khẩu admin"
            style={{ padding: 10, borderRadius: 8, border: "1px solid #d1d5db" }}
          />
          <button
            type="submit"
            disabled={loading}
            style={{
              padding: 11,
              borderRadius: 8,
              border: "none",
              background: "#7c3aed",
              color: "#fff",
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            {loading ? "Đang kiểm tra quyền..." : "Đăng nhập Admin"}
          </button>
          <button type="button" onClick={onBackHome}>
            Quay lại trang chủ
          </button>
        </form>
      )}
    </div>
  );
}