// src/components/Navbar.jsx
import React from "react";
import { useAuth } from "../context/AuthContext";

export default function Navbar({ currentPath, onNavigate }) {
  const {
    user,
    isAdmin,
    logout,
    setAuthModalOpen,
    setAuthMode,
    setPendingAdminNav,
    showToast,
  } = useAuth();

  const handleAdminClick = (e) => {
    e.preventDefault();

    if (!user) {
      setPendingAdminNav(true);
      setAuthMode("login");
      setAuthModalOpen(true);
      showToast("Vui lòng đăng nhập bằng tài khoản Admin để vào Trang Quản Trị", "error");
      return;
    }

    if (!isAdmin) {
      showToast("Bạn không có quyền Admin để truy cập Trang Quản Trị!", "error");
      return;
    }

    onNavigate("/admin");
  };

  return (
    <header
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "12px 24px",
        borderBottom: "1px solid #e5e7eb",
        background: "#fff",
      }}
    >
      <div
        onClick={() => onNavigate("/")}
        style={{ cursor: "pointer", fontWeight: 700, fontSize: 18 }}
      >
        TOON CINEMA
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        {!user ? (
          <>
            <button
              type="button"
              onClick={() => {
                setPendingAdminNav(false);
                setAuthMode("login");
                setAuthModalOpen(true);
              }}
            >
              Đăng nhập
            </button>
            <button
              type="button"
              onClick={() => {
                setPendingAdminNav(false);
                setAuthMode("register");
                setAuthModalOpen(true);
              }}
            >
              Đăng ký
            </button>
          </>
        ) : (
          <>
            <span>Xin chào, {user.full_name || user.email}</span>
            <button type="button" onClick={logout}>
              Thoát
            </button>
          </>
        )}

        <button
          type="button"
          onClick={handleAdminClick}
          style={{
            padding: "8px 14px",
            borderRadius: 8,
            border: "1px solid #d1d5db",
            background: currentPath === "/admin" ? "#ede9fe" : "#fff",
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          Trang Quản Trị
        </button>
      </div>
    </header>
  );
}