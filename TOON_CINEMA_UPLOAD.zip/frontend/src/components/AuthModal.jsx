import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";

export default function AuthModal({ onAuthSuccess }) {
  const {
    authModalOpen,
    setAuthModalOpen,
    authMode,
    setAuthMode,
    login,
    register,
  } = useAuth();

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (!authModalOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg("");
    setSubmitting(true);

    try {
      let loggedUser;
      if (authMode === "login") {
        loggedUser = await login(email.trim(), password);
      } else {
        loggedUser = await register(fullName.trim(), email.trim(), password);
      }
      setFullName("");
      setEmail("");
      setPassword("");
      if (onAuthSuccess) onAuthSuccess(loggedUser);
    } catch (err) {
      setErrorMsg(err.message || "Có lỗi xảy ra");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        backgroundColor: "rgba(0,0,0,0.55)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 9990,
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: 420,
          background: "#fff",
          borderRadius: 14,
          padding: 24,
          position: "relative",
        }}
      >
        <button
          type="button"
          onClick={() => setAuthModalOpen(false)}
          style={{
            position: "absolute",
            top: 14,
            right: 16,
            border: "none",
            background: "transparent",
            fontSize: 20,
            cursor: "pointer",
          }}
        >
          ×
        </button>

        <h3 style={{ marginTop: 0, marginBottom: 4 }}>
          {authMode === "login" ? "Đăng nhập tài khoản" : "Đăng ký tài khoản"}
        </h3>
        <p style={{ marginTop: 0, color: "#6b7280", fontSize: 14 }}>
          TOON CINEMA Member
        </p>

        <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
          <button
            type="button"
            onClick={() => {
              setAuthMode("login");
              setErrorMsg("");
            }}
            style={{
              flex: 1,
              padding: 8,
              borderRadius: 8,
              border: "1px solid #d1d5db",
              background: authMode === "login" ? "#7c3aed" : "#f9fafb",
              color: authMode === "login" ? "#fff" : "#111827",
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            Đăng nhập
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMode("register");
              setErrorMsg("");
            }}
            style={{
              flex: 1,
              padding: 8,
              borderRadius: 8,
              border: "1px solid #d1d5db",
              background: authMode === "register" ? "#7c3aed" : "#f9fafb",
              color: authMode === "register" ? "#fff" : "#111827",
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            Đăng ký
          </button>
        </div>

        {errorMsg && (
          <div
            style={{
              background: "#fef2f2",
              color: "#b91c1c",
              padding: "10px 12px",
              borderRadius: 8,
              marginBottom: 14,
              fontSize: 14,
            }}
          >
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {authMode === "register" && (
            <div>
              <label style={{ display: "block", fontSize: 13, marginBottom: 4 }}>
                Họ và tên
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Nhập họ và tên"
                style={{ width: "100%", padding: 10, borderRadius: 8, border: "1px solid #d1d5db" }}
              />
            </div>
          )}

          <div>
            <label style={{ display: "block", fontSize: 13, marginBottom: 4 }}>Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com"
              style={{ width: "100%", padding: 10, borderRadius: 8, border: "1px solid #d1d5db" }}
            />
          </div>

          <div>
            <label style={{ display: "block", fontSize: 13, marginBottom: 4 }}>Mật khẩu</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              style={{ width: "100%", padding: 10, borderRadius: 8, border: "1px solid #d1d5db" }}
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            style={{
              marginTop: 4,
              padding: 11,
              borderRadius: 8,
              border: "none",
              background: "#7c3aed",
              color: "#fff",
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            {submitting
              ? "Đang xử lý..."
              : authMode === "login"
              ? "Đăng nhập"
              : "Tạo tài khoản"}
          </button>
        </form>
      </div>
    </div>
  );
}