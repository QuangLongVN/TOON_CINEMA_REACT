import React, { createContext, useContext, useState, useEffect } from "react";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem("toon_user");
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [token, setToken] = useState(() => localStorage.getItem("toon_token") || "");
  const [toast, setToast] = useState(null); // { type: 'success' | 'error', message: string }
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState("login"); // 'login' | 'register'
  const [pendingAdminNav, setPendingAdminNav] = useState(false);

  const showToast = (message, type = "success") => {
    setToast({ message, type });
    setTimeout(() => {
      setToast((prev) => (prev?.message === message ? null : prev));
    }, 3500);
  };

  const saveSession = (userData, authToken) => {
    setUser(userData);
    setToken(authToken || "");
    if (userData) {
      localStorage.setItem("toon_user", JSON.stringify(userData));
    } else {
      localStorage.removeItem("toon_user");
    }
    if (authToken) {
      localStorage.setItem("toon_token", authToken);
    } else {
      localStorage.removeItem("toon_token");
    }
  };

  // Đồng bộ lại thông tin user (đặc biệt là role) từ backend khi có token
  useEffect(() => {
    if (!token) return;
    fetch(`${API_URL}/auth/me`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        const current = data?.user || data;
        if (current && current.id) {
          saveSession(current, token);
        }
      })
      .catch(() => {});
  }, [token]);

  const login = async (email, password) => {
    const res = await fetch(`${API_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();

    if (!res.ok) {
      const msg = data.message || "Đăng nhập thất bại";
      showToast(msg, "error");
      throw new Error(msg);
    }

    const loggedUser = data.user || data;
    const authToken = data.token || "";
    saveSession(loggedUser, authToken);
    setAuthModalOpen(false);
    showToast(`Đăng nhập thành công! Xin chào ${loggedUser.full_name || loggedUser.email}`, "success");
    return loggedUser;
  };

  const register = async (fullName, email, password) => {
    const res = await fetch(`${API_URL}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        full_name: fullName,
        email,
        password,
      }),
    });
    const data = await res.json();

    if (!res.ok) {
      const msg = data.message || "Không thể đăng ký tài khoản";
      showToast(msg, "error");
      throw new Error(msg);
    }

    const createdUser = data.user || { full_name: fullName, email, role: "user" };
    const authToken = data.token || "";
    if (authToken) {
      saveSession(createdUser, authToken);
    }
    setAuthModalOpen(false);
    showToast("Đăng ký tài khoản thành công!", "success");
    return createdUser;
  };

  const logout = () => {
    saveSession(null, "");
    setPendingAdminNav(false);
    showToast("Đã đăng xuất khỏi hệ thống", "success");
  };

  const isAdmin = Boolean(user && String(user.role).toLowerCase() === "admin");

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAdmin,
        toast,
        showToast,
        authModalOpen,
        setAuthModalOpen,
        authMode,
        setAuthMode,
        pendingAdminNav,
        setPendingAdminNav,
        login,
        register,
        logout,
      }}
    >
      {children}

      {/* Thanh thông báo nổi */}
      {toast && (
        <div
          style={{
            position: "fixed",
            top: 20,
            right: 20,
            zIndex: 9999,
            padding: "12px 18px",
            borderRadius: 10,
            color: "#fff",
            fontWeight: 600,
            boxShadow: "0 8px 24px rgba(0,0,0,0.2)",
            backgroundColor: toast.type === "error" ? "#dc2626" : "#16a34a",
          }}
        >
          {toast.message}
        </div>
      )}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}