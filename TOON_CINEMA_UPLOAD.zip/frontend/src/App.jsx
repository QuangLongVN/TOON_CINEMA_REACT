import { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route, Link, useNavigate } from "react-router-dom";

import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import Dashboard from "./components/Dashboard";

import Movies from "./pages/Movies";
import Rooms from "./pages/Rooms";
import Showtimes from "./pages/Showtimes";
import Seats from "./pages/Seats";
import Products from "./pages/Products";
import UserHome from "./pages/UserHome";

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

function getStoredUser() {
    try {
        const raw = localStorage.getItem("toon_user") || localStorage.getItem("user");
        return raw ? JSON.parse(raw) : null;
    } catch {
        return null;
    }
}

function saveStoredUser(userObj, token) {
    if (userObj) {
        localStorage.setItem("toon_user", JSON.stringify(userObj));
        localStorage.setItem("user", JSON.stringify(userObj));
    } else {
        localStorage.removeItem("toon_user");
        localStorage.removeItem("user");
    }
    if (token) {
        localStorage.setItem("toon_token", token);
        localStorage.setItem("token", token);
    }
}

function isAdminUser(userObj) {
    return Boolean(userObj && String(userObj.role || "").toLowerCase() === "admin");
}

function AdminGate({ children, onNotify }) {
    const navigate = useNavigate();
    const [currentUser, setCurrentUser] = useState(() => getStoredUser());
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [errorMsg, setErrorMsg] = useState("");
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        const syncUser = () => setCurrentUser(getStoredUser());
        window.addEventListener("storage", syncUser);
        return () => window.removeEventListener("storage", syncUser);
    }, []);

    if (isAdminUser(currentUser)) {
        return children;
    }

    async function handleAdminLogin(e) {
        e.preventDefault();
        setErrorMsg("");
        setSubmitting(true);

        try {
            const res = await fetch(`${API_BASE}/auth/login`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    email: email.trim(),
                    password,
                }),
            });

            const data = await res.json();
            if (!res.ok) {
                const msg = data.message || "Đăng nhập thất bại";
                setErrorMsg(msg);
                onNotify(msg, "error");
                return;
            }

            const loggedUser = data.user || data;
            const token = data.token || "";
            saveStoredUser(loggedUser, token);
            setCurrentUser(loggedUser);

            if (!isAdminUser(loggedUser)) {
                const msg = `Tài khoản "${loggedUser.email || email}" có quyền "${loggedUser.role || "user"}", không thể vào Trang Quản Trị.`;
                setErrorMsg(msg);
                onNotify(msg, "error");
                return;
            }

            onNotify(`Đăng nhập Admin thành công! Xin chào ${loggedUser.full_name || loggedUser.email}`, "success");
        } catch {
            const msg = "Không thể kết nối tới Backend. Hãy kiểm tra server Node.js.";
            setErrorMsg(msg);
            onNotify(msg, "error");
        } finally {
            setSubmitting(false);
        }
    }

    function handleLogoutCurrent() {
        saveStoredUser(null, "");
        localStorage.removeItem("toon_token");
        localStorage.removeItem("token");
        setCurrentUser(null);
        setErrorMsg("");
        onNotify("Đã đăng xuất tài khoản hiện tại", "success");
    }

    return (
        <div
            style={{
                minHeight: "100vh",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: "#f8fafc",
                padding: "24px",
            }}
        >
            <div
                style={{
                    width: "100%",
                    maxWidth: "420px",
                    background: "#ffffff",
                    border: "1px solid #e2e8f0",
                    borderRadius: "14px",
                    padding: "28px",
                    boxShadow: "0 10px 25px rgba(15, 23, 42, 0.08)",
                }}
            >
                <h2 style={{ margin: "0 0 6px", fontSize: "20px", color: "#0f172a" }}>
                    Xác thực quyền Admin
                </h2>
                <p style={{ margin: "0 0 18px", fontSize: "13px", color: "#64748b" }}>
                    Khu vực <strong>TOON CINEMA Admin</strong> yêu cầu tài khoản có quyền <strong>admin</strong>.
                </p>

                {currentUser && !isAdminUser(currentUser) && (
                    <div
                        style={{
                            background: "#fef2f2",
                            border: "1px solid #fecaca",
                            color: "#b91c1c",
                            padding: "12px",
                            borderRadius: "10px",
                            fontSize: "13px",
                            marginBottom: "14px",
                        }}
                    >
                        Đang đăng nhập tài khoản <strong>{currentUser.email}</strong> (role:{" "}
                        <strong>{currentUser.role || "user"}</strong>). Tài khoản này không có quyền truy cập trang quản trị.
                    </div>
                )}

                {errorMsg && (
                    <div
                        style={{
                            background: "#fef2f2",
                            border: "1px solid #fecaca",
                            color: "#b91c1c",
                            padding: "10px 12px",
                            borderRadius: "10px",
                            fontSize: "13px",
                            marginBottom: "14px",
                        }}
                    >
                        {errorMsg}
                    </div>
                )}

                <form onSubmit={handleAdminLogin} style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                    <div>
                        <label style={{ display: "block", fontSize: "13px", fontWeight: 600, marginBottom: "4px" }}>
                            Email Admin
                        </label>
                        <input
                            type="email"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="admin@gmail.com"
                            style={{
                                width: "100%",
                                padding: "10px 12px",
                                borderRadius: "8px",
                                border: "1px solid #cbd5e1",
                                fontSize: "14px",
                                boxSizing: "border-box",
                            }}
                        />
                    </div>

                    <div>
                        <label style={{ display: "block", fontSize: "13px", fontWeight: 600, marginBottom: "4px" }}>
                            Mật khẩu
                        </label>
                        <input
                            type="password"
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Nhập mật khẩu"
                            style={{
                                width: "100%",
                                padding: "10px 12px",
                                borderRadius: "8px",
                                border: "1px solid #cbd5e1",
                                fontSize: "14px",
                                boxSizing: "border-box",
                            }}
                        />
                    </div>

                    <button
                        type="submit"
                        disabled={submitting}
                        style={{
                            marginTop: "4px",
                            padding: "11px",
                            borderRadius: "8px",
                            border: "none",
                            background: "#7c3aed",
                            color: "#ffffff",
                            fontWeight: 600,
                            fontSize: "14px",
                            cursor: "pointer",
                        }}
                    >
                        {submitting ? "Đang kiểm tra..." : "Đăng nhập Admin"}
                    </button>
                </form>

                <div
                    style={{
                        marginTop: "16px",
                        paddingTop: "14px",
                        borderTop: "1px solid #f1f5f9",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        gap: "8px",
                    }}
                >
                    <button
                        type="button"
                        onClick={() => navigate("/")}
                        style={{
                            padding: "8px 12px",
                            borderRadius: "8px",
                            border: "1px solid #cbd5e1",
                            background: "#ffffff",
                            color: "#334155",
                            fontSize: "13px",
                            fontWeight: 600,
                            cursor: "pointer",
                        }}
                    >
                        ← Về trang chủ
                    </button>

                    {currentUser && (
                        <button
                            type="button"
                            onClick={handleLogoutCurrent}
                            style={{
                                padding: "8px 12px",
                                borderRadius: "8px",
                                border: "1px solid #fecaca",
                                background: "#fff1f2",
                                color: "#be123c",
                                fontSize: "13px",
                                fontWeight: 600,
                                cursor: "pointer",
                            }}
                        >
                            Đăng xuất ({currentUser.email})
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
}

function AdminLayout() {
    const [active, setActive] = useState("dashboard");

    function renderPage() {
        switch (active) {
            case "movies":
                return <Movies />;
            case "rooms":
                return <Rooms />;
            case "showtimes":
                return <Showtimes />;
            case "seats":
                return <Seats />;
            case "products":
                return <Products />;
            default:
                return <Dashboard />;
        }
    }

    return (
        <div className="app-layout">
            <Sidebar active={active} setActive={setActive} />

            <main className="main-content">
                <Header active={active} />

                <div style={{ padding: "12px 35px 0", display: "flex", justifyContent: "flex-end" }}>
                    <Link
                        to="/"
                        style={{
                            fontSize: "13px",
                            fontWeight: 600,
                            color: "#7c3aed",
                            textDecoration: "none",
                            background: "#f3e8ff",
                            padding: "6px 14px",
                            borderRadius: "8px",
                        }}
                    >
                        ← Xem trang khách hàng (User)
                    </Link>
                </div>

                <div className="page-content">{renderPage()}</div>
            </main>
        </div>
    );
}

export default function App() {
    const [toast, setToast] = useState(null);

    function notify(message, type = "success") {
        setToast({ message, type });
        setTimeout(() => {
            setToast((prev) => (prev?.message === message ? null : prev));
        }, 3500);
    }

    return (
        <BrowserRouter>
            {toast && (
                <div
                    style={{
                        position: "fixed",
                        top: "18px",
                        right: "18px",
                        zIndex: 99999,
                        padding: "11px 16px",
                        borderRadius: "10px",
                        background: toast.type === "error" ? "#dc2626" : "#16a34a",
                        color: "#ffffff",
                        fontSize: "13px",
                        fontWeight: 600,
                        boxShadow: "0 8px 20px rgba(0, 0, 0, 0.18)",
                    }}
                >
                    {toast.message}
                </div>
            )}

            <Routes>
                <Route path="/" element={<UserHome />} />
                <Route
                    path="/admin/*"
                    element={
                        <AdminGate onNotify={notify}>
                            <AdminLayout />
                        </AdminGate>
                    }
                />
            </Routes>
        </BrowserRouter>
    );
}